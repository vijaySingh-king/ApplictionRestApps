'use strict';

var App = angular.module('myApp',[]);
alert("appp");